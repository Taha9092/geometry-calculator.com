from flask import Flask, render_template
import matplotlib.pyplot as plt
import io
import base64

app = Flask(__name__)

@app.route("/")
def home():
    x = [1, 2, 3, 4, 5]
    y = [2, 4, 1, 8, 7]

    fig, ax = plt.subplots()
    ax.plot(x, y)

    img = io.BytesIO()
    fig.savefig(img, format="png")
    img.seek(0)

    plot_url = base64.b64encode(img.getvalue()).decode()

    return render_template(
        "chart.html",
        plot_url=plot_url
    )

if __name__ == "__main__":
    app.run(debug=True)